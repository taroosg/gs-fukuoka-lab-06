<?php

function connect_to_db()
{
}
