<?php
// session変数を定義して値を入れよう
