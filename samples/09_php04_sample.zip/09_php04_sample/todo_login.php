<!DOCTYPE html>
<html lang="ja">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>todoリストログイン画面</title>
</head>

<body>
  <form>
    <fieldset>
      <legend>todoリストログイン画面</legend>
      <div>
        username: <input type="text">
      </div>
      <div>
        password: <input type="text">
      </div>
      <div>
        <button>Login</button>
      </div>
      <a href="todo_register.php">or register</a>
    </fieldset>
  </form>

</body>

</html>